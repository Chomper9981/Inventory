using InventorySystem.Models;
using InventorySystem.Views;
using UnityEngine;

public class UIManager : MonoBehaviour
{
    [SerializeField] private GameObject _playerInventoryPanel;
    [SerializeField] private GameObject _shopPanel;
    [SerializeField] private GameObject _menuPanel;
    [SerializeField] private GameObject _playerInventoryView;
    // [SerializeField] private GameObject _shopInventoryView;

    public void OpenPlayerInventory()
    {
        _playerInventoryPanel.SetActive(true);
        _playerInventoryView.SetActive(true);
        
    }

    public void OpenShop()
    {
        _shopPanel.SetActive(true);
        // _shopInventoryView.SetActive(true);
    }

    public void OpenMenu()
    {
        _menuPanel.SetActive(true);
    }

    public void CloseAllPanels()
    {
        _playerInventoryPanel.SetActive(false);
        _shopPanel.SetActive(false);    
        _menuPanel.SetActive(false);
        _playerInventoryView.SetActive(false);
        // _shopInventoryView.SetActive(false);
    }

    // public void InitPlayer(Inventory inventory)
    // {
    //     _playerInventoryView.InitInventoryView(inventory);
    // }

    // public void OnInventoryChange(Inventory inventory)
    // {
    //     _playerInventoryView.UpdateInventoryView(inventory);
    // }

    
    
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
