using System.Collections.Generic;
using UnityEngine;

namespace InventorySystem.Managers
{
    public class SpriteManager
    {
        private Dictionary<string, Sprite> _spriteCache;

        public void LoadSpriteSheet()
        {
            if (_spriteCache == null)
                _spriteCache = new Dictionary<string, Sprite>();

            Sprite[] sprites = Resources.LoadAll<Sprite>("");
            foreach (var sprite in sprites)
            {
                if (!_spriteCache.ContainsKey(sprite.name))
                {
                    _spriteCache[sprite.name] = sprite;
                }
            }
        }
        public Sprite GetSprite(string spriteName)
        {
            if (_spriteCache != null && _spriteCache.TryGetValue(spriteName, out var sprite))
            {
                return sprite;
            }

            Debug.LogWarning($"Sprite not found in cache: {spriteName}");
            return null;
        }
    }
}