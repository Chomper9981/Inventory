using System.Linq;
using InventorySystem.Database;
using InventorySystem.Models;
using UnityEngine;
using UnityEngine.Events;

namespace InventorySystem.Managers
{
    public class InventoryManagers //: MonoBehaviour
    {
        private DataManager dataManager = new DataManager();
        public Item[] GetAllInventoryItemsToArray()
        {
            Inventory items = dataManager.Load("inventory");
            return items.Items.Values.ToArray();
        }
        public bool UseItem(int itemId)
        {
            Inventory temp = dataManager.Load("inventory");
            Item item = temp.Items[itemId];
            if(itemId == 999)
            {
                return false;
            }
            if(item.Amount > 1)
            {
                item.Amount--;
            }
            else
            {
                temp.Items.Remove(item.Id);
            }
            dataManager.Save("inventory", temp);
            // OnInventoryChange?.Invoke(temp);
            return true;
        }
        // public UnityEvent<Inventory> OnInventoryChange;

        // public static InventoryManagers Instance;

        // private void Awake()
        // {
        //     if(Instance != null) Destroy(Instance);
        //     Instance = this;
        // }
    }
        
}