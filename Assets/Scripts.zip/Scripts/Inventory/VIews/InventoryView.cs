using UnityEngine;
using InventorySystem.Models;
using InventorySystem.Managers;
using UnityEngine.UI;
using InventorySystem.Database;
using TMPro;

namespace InventorySystem.Views
{
    public class InventoryView : MonoBehaviour
    {
        [SerializeField] private PlayerInventorySlot _playerInventorySlotPrefabs;
        [SerializeField] private Transform _playerInventorySlotContainer;
        [SerializeField] private int inventorySize = 36;
        [SerializeField] private Image CoinImage;
        [SerializeField] private TMP_Text CoinText;
        private PlayerInventorySlot[] playerInventorySlots;
        private InventoryManagers _inventoryManagers = new InventoryManagers();
        // private LoadDatabase loadDatabase = new LoadDatabase();
        
        public void GenerateInventorySlot()
        {
            playerInventorySlots = new PlayerInventorySlot[inventorySize];
            for(int i = 0; i < inventorySize; i++)
            {
                playerInventorySlots[i] = Instantiate(_playerInventorySlotPrefabs, _playerInventorySlotContainer);
                playerInventorySlots[i].OnUseItem.AddListener(OnPlayerInventorySlotClick);
            }
        }
        public void UpdateInventory()
        {
            Item[] items = _inventoryManagers.GetAllInventoryItemsToArray();
            foreach(var slot in playerInventorySlots)
            {
                slot.gameObject.SetActive(false);
            }

            for (int i = 0; i < items.Length; i++)
            {
                if(items[i].Id == 999)
                {
                    CoinImage.sprite = Resources.Load<Sprite>(items[i].SpriteName);
                    CoinText.text = items[i].Amount.ToString();
                }
                else
                {
                    playerInventorySlots[i].gameObject.SetActive(true);
                    playerInventorySlots[i].SetItem(items[i]);       
                }
                
            }
        }

        public void OnPlayerInventorySlotClick(Item item)
        {
            
            _inventoryManagers.UseItem(item.Id);
            UpdateInventory();
        }
        private void Start()
        {
            
            // loadDatabase.LoadItemsData();
            GenerateInventorySlot();
            UpdateInventory();
            
        }
        
    }
}