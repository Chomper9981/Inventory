// using UnityEngine;
// using InventorySystem.Models;
// using InventorySystem.Managers;
// using UnityEngine.UI;
// using InventorySystem.Database;
// using TMPro;

// namespace InventorySystem.Views
// {
//     public class ShopView : MonoBehaviour
//     {
//         [SerializeField] private PlayerShopSlot _playerShopSlot;
//         [SerializeField] private Transform _playerShopSlotContainer;
//         [SerializeField] private int playerShopSize = 36;
//         [SerializeField] private Image CoinImage;
//         [SerializeField] private TMP_Text CoinText;
//         [SerializeField] private ShopSlot _shopSlot;
//         [SerializeField] private Transform _shopSlotContainer;
//         [SerializeField] private int shopSize = 36;

//         private PlayerShopSlot[] playerInventorySlots;
//         private InventoryManagers _inventoryManagers = new InventoryManagers();
//         // private LoadDatabase loadDatabase = new LoadDatabase();
        
//         public void GenerateInventorySlot()
//         {
//             playerInventorySlots = new PlayerShopSlot[playerShopSize];
//             for(int i = 0; i < playerShopSize; i++)
//             {
//                 playerInventorySlots[i] = Instantiate(_playerShopSlot, _playerShopSlotContainer);
//                 playerInventorySlots[i].OnSellItem.AddListener(OnPlayerShopSlotClick);
//             }
//         }
//         public void UpdateInventory()
//         {
//             Item[] items = _inventoryManagers.GetAllInventoryItemsToArray();
//             foreach(var slot in playerInventorySlots)
//             {
//                 slot.gameObject.SetActive(false);
//             }

//             for (int i = 0; i < items.Length; i++)
//             {
//                 if(items[i].Id == 999)
//                 {
//                     CoinImage = Resources.Load<Image>(items[i].SpriteName);
//                     CoinText.text = items[i].Amount.ToString();
//                 }
//                 else
//                 {
//                     playerInventorySlots[i].gameObject.SetActive(true);
//                     playerInventorySlots[i].SetItem(items[i]);       
//                 }
                
//             }
//         }

//         public void OnPlayerInventorySlotClick(Item item)
//         {
            
//             _inventoryManagers.UseItem(item.Id);
//             UpdateInventory();
//         }
//         private void Start()
//         {
            
//             // loadDatabase.LoadItemsData();
//             GenerateInventorySlot();
//             UpdateInventory();
            
//         }
        
//     }
// }