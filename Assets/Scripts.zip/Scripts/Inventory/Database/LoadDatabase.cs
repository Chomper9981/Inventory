using System.Collections.Generic;
using UnityEngine;
using InventorySystem.Models;

namespace InventorySystem.Database
{
    public class LoadDatabase
    {
        private DataManager dataManager = new DataManager();
        public Inventory LoadItemsData()
        {
            Inventory inventory = new Inventory();

            string csv = Resources.Load<TextAsset>("Items_data").text;
            Debug.Log(csv);
            
            string[] lines = csv.Split('\n');
            for (int i = 1; i < lines.Length; i++)
            {
                string[] fields = lines[i].Split(',');
                Item item = new Item();
                item.Id = int.Parse(fields[0]);
                item.Name = fields[1];
                item.SpriteName = fields[2];
                item.PricePurchase = int.Parse(fields[3]);
                item.PriceSell = int.Parse(fields[4]);
                item.Amount = 10;
                inventory.Items.Add(item.Id, item);
                Debug.Log(item.Id + " " + item.Name + " " + item.SpriteName + " " + item.PricePurchase + " " + item.PriceSell + " " + item.Amount);
            }
            

            foreach (var item in inventory.Items)
            {
                Debug.Log(item.Value.Id + " " + item.Value.Name + " " + item.Value.SpriteName + " " + item.Value.PricePurchase + " " + item.Value.PriceSell + " " + item.Value.Amount);
            }
            dataManager.Save("inventory", inventory);
            return inventory;
        }
    }
}